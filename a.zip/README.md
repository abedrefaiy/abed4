# YT-Sub-Like
ออโต้ Sub &amp; Like YouTube

#  INSTALL TERMUX
apt-get update && apt-get upgrade

pkg install git

pkg install python2

pkg install nano

git clone https://github.com/FewTeamBot/YT-Sub-Like

python2 hakyt.py

# edit file
nano gmail.txt ใส่emailบอทพร้อมรหัสผ่าน
เช่น emailyou@gmail.com:pass

nano yt.txt ใส่ลิ้งช่องหรือลิ้งคลิป(เลือกอย่างเดียวจะเอาSubหรือLike)ห้ามให้มี(/)ต่อท้ายลิ้ง
เช่น https://www.youtube.com/channel/UC7zcJU_Yb5DIrqEf9AcLbXw
